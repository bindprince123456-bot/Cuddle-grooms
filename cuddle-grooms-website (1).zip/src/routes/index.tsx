import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  motion,
  AnimatePresence,
  useScroll,
  useTransform,
  useSpring,
  useMotionValue,
  useInView,
  animate,
  type MotionValue,
} from "framer-motion";
import Lenis from "lenis";
import { ArrowUpRight, Phone, MapPin, Clock, Star, Plus, Sparkles, Heart } from "lucide-react";
import dog from "@/assets/dog.png";
import cat from "@/assets/cat.png";
import paw from "@/assets/paw.png";
import kit from "@/assets/kit.png";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Cuddle Grooms — Patient, care-first pet grooming in Chembur" },
      {
        name: "description",
        content:
          "Gentle grooming, baths and haircuts for dogs and cats in Chembur, Mumbai. Rated 5.0 by pet parents. Call +91 85911 89518.",
      },
      { property: "og:title", content: "Cuddle Grooms — Good grooming. Great little moments." },
      {
        property: "og:description",
        content: "Care-first pet grooming and essentials at Sindhi Society, Chembur, Mumbai.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

const PHONE = "+918591189518";
const PHONE_LABEL = "+91 85911 89518";
const MAPS = "https://www.google.com/maps/search/?api=1&query=Cuddle+Grooms+Sindhi+Society+Chembur+Mumbai";
const ease = [0.22, 1, 0.36, 1] as const;

/* ------------------------------ helpers ------------------------------ */

function useLenis() {
  useEffect(() => {
    const lenis = new Lenis({ duration: 1.25, smoothWheel: true });
    let id = 0;
    const raf = (t: number) => {
      lenis.raf(t);
      id = requestAnimationFrame(raf);
    };
    id = requestAnimationFrame(raf);
    const onClick = (e: MouseEvent) => {
      const a = (e.target as HTMLElement).closest("a[data-scroll]") as HTMLAnchorElement | null;
      if (!a) return;
      e.preventDefault();
      lenis.scrollTo(a.getAttribute("href")!, { offset: -40 });
    };
    document.addEventListener("click", onClick);
    return () => {
      cancelAnimationFrame(id);
      document.removeEventListener("click", onClick);
      lenis.destroy();
    };
  }, []);
}

function SplitWords({ text, className, delay = 0 }: { text: string; className?: string; delay?: number }) {
  return (
    <span className={className}>
      {text.split(" ").map((w, i) => (
        <span key={i} className="inline-block overflow-hidden pb-[0.12em] align-bottom">
          <motion.span
            className="inline-block"
            initial={{ y: "110%", rotate: 6 }}
            animate={{ y: "0%", rotate: 0 }}
            transition={{ duration: 1.1, ease, delay: delay + i * 0.07 }}
          >
            {w}&nbsp;
          </motion.span>
        </span>
      ))}
    </span>
  );
}

function Reveal({ children, delay = 0, className }: { children: ReactNode; delay?: number; className?: string }) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 50, filter: "blur(10px)" }}
      whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
      viewport={{ once: true, margin: "-10%" }}
      transition={{ duration: 1, ease, delay }}
    >
      {children}
    </motion.div>
  );
}

function Magnetic({ children, className }: { children: ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const x = useSpring(0, { stiffness: 200, damping: 15 });
  const y = useSpring(0, { stiffness: 200, damping: 15 });
  return (
    <motion.div
      ref={ref}
      className={`inline-block ${className ?? ""}`}
      style={{ x, y }}
      onMouseMove={(e) => {
        const r = ref.current!.getBoundingClientRect();
        x.set((e.clientX - r.left - r.width / 2) * 0.35);
        y.set((e.clientY - r.top - r.height / 2) * 0.35);
      }}
      onMouseLeave={() => {
        x.set(0);
        y.set(0);
      }}
    >
      {children}
    </motion.div>
  );
}

function Counter({ to, decimals = 0, suffix = "" }: { to: number; decimals?: number; suffix?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });
  const [v, setV] = useState(0);
  useEffect(() => {
    if (!inView) return;
    const c = animate(0, to, { duration: 2.2, ease, onUpdate: setV });
    return () => c.stop();
  }, [inView, to]);
  return (
    <span ref={ref}>
      {v.toFixed(decimals)}
      {suffix}
    </span>
  );
}

/* ------------------------------ cursor ------------------------------ */

function Cursor() {
  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const sx = useSpring(x, { stiffness: 500, damping: 40 });
  const sy = useSpring(y, { stiffness: 500, damping: 40 });
  const [hover, setHover] = useState(false);
  const [enabled, setEnabled] = useState(false);
  useEffect(() => {
    if (!window.matchMedia("(pointer: fine)").matches) return;
    setEnabled(true);
    const move = (e: MouseEvent) => {
      x.set(e.clientX);
      y.set(e.clientY);
      setHover(!!(e.target as HTMLElement).closest("a,button"));
    };
    window.addEventListener("mousemove", move);
    return () => window.removeEventListener("mousemove", move);
  }, [x, y]);
  if (!enabled) return null;
  return (
    <motion.div
      className="pointer-events-none fixed left-0 top-0 z-[70] mix-blend-multiply"
      style={{ x: sx, y: sy }}
    >
      <motion.div
        className="-translate-x-1/2 -translate-y-1/2 rounded-full bg-peach"
        animate={{ width: hover ? 64 : 16, height: hover ? 64 : 16, opacity: hover ? 0.7 : 1 }}
        transition={{ type: "spring", stiffness: 300, damping: 20 }}
      />
    </motion.div>
  );
}

/* ------------------------------ preloader ------------------------------ */

function Preloader({ onDone }: { onDone: () => void }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    const c = animate(0, 100, {
      duration: 1.8,
      ease: [0.65, 0, 0.35, 1],
      onUpdate: (v) => setN(Math.round(v)),
      onComplete: () => setTimeout(onDone, 250),
    });
    return () => c.stop();
  }, [onDone]);
  return (
    <motion.div
      className="fixed inset-0 z-[80] flex flex-col items-center justify-center bg-ink text-cream"
      exit={{ clipPath: "inset(0 0 100% 0)" }}
      initial={{ clipPath: "inset(0 0 0% 0)" }}
      transition={{ duration: 1, ease: [0.76, 0, 0.24, 1] }}
    >
      <motion.img
        src={paw}
        alt=""
        className="h-20 w-20"
        animate={{ rotate: [0, -12, 12, 0], scale: [1, 1.1, 1] }}
        transition={{ duration: 1.2, repeat: Infinity }}
      />
      <div className="mt-8 font-serif text-7xl italic tabular-nums md:text-9xl">{n}%</div>
      <div className="mt-3 text-xs uppercase tracking-[0.4em] opacity-60">Fluffing things up</div>
    </motion.div>
  );
}

/* ------------------------------ nav ------------------------------ */

function Nav() {
  const { scrollY } = useScroll();
  const [hidden, setHidden] = useState(false);
  useEffect(
    () =>
      scrollY.on("change", (v) => {
        const prev = scrollY.getPrevious() ?? 0;
        setHidden(v > prev && v > 300);
      }),
    [scrollY],
  );
  return (
    <motion.header
      className="fixed inset-x-0 top-4 z-50 flex justify-center px-4"
      animate={{ y: hidden ? -120 : 0 }}
      transition={{ duration: 0.5, ease }}
    >
      <nav className="glass flex w-full max-w-5xl items-center justify-between rounded-full py-2 pl-5 pr-2">
        <a href="#top" data-scroll className="flex items-center gap-2 font-display text-lg font-bold">
          <img src={paw} alt="" className="h-7 w-7" />
          Cuddle<span className="font-serif font-normal italic">Grooms</span>
        </a>
        <div className="hidden items-center gap-7 text-sm font-medium md:flex">
          {[
            ["Care", "#care"],
            ["Services", "#services"],
            ["First visit", "#visit"],
            ["Reviews", "#reviews"],
          ].map(([l, h]) => (
            <a key={h} href={h} data-scroll className="group relative">
              {l}
              <span className="absolute -bottom-1 left-0 h-px w-full origin-right scale-x-0 bg-ink transition-transform duration-500 group-hover:origin-left group-hover:scale-x-100" />
            </a>
          ))}
        </div>
        <a
          href={`tel:${PHONE}`}
          className="flex items-center gap-2 rounded-full bg-ink px-5 py-3 text-sm font-semibold text-cream transition-transform hover:scale-105"
        >
          <Phone size={14} /> Call to book
        </a>
      </nav>
    </motion.header>
  );
}

/* ------------------------------ hero ------------------------------ */

function Float({
  src,
  className,
  mx,
  my,
  depth,
  delay = 0,
  dur = 6,
}: {
  src: string;
  className: string;
  mx: MotionValue<number>;
  my: MotionValue<number>;
  depth: number;
  delay?: number;
  dur?: number;
}) {
  const x = useTransform(mx, (v) => v * depth);
  const y = useTransform(my, (v) => v * depth);
  return (
    <motion.div className={`absolute ${className}`} style={{ x, y }}>
      <motion.img
        src={src}
        alt=""
        className="h-full w-full object-contain drop-shadow-[0_30px_40px_oklch(0.24_0.03_170/0.18)]"
        initial={{ scale: 0, rotate: -30 }}
        animate={{ scale: 1, rotate: 0, y: [0, -18, 0] }}
        transition={{
          scale: { duration: 1.2, ease, delay },
          rotate: { duration: 1.2, ease, delay },
          y: { duration: dur, repeat: Infinity, ease: "easeInOut", delay },
        }}
      />
    </motion.div>
  );
}

function Hero({ ready }: { ready: boolean }) {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const scale = useTransform(scrollYProgress, [0, 1], [1, 0.85]);
  const radius = useTransform(scrollYProgress, [0, 1], [0, 64]);
  const textY = useTransform(scrollYProgress, [0, 1], [0, 200]);
  const mx = useSpring(0, { stiffness: 60, damping: 20 });
  const my = useSpring(0, { stiffness: 60, damping: 20 });

  return (
    <section
      id="top"
      ref={ref}
      className="relative h-[100svh] min-h-[720px]"
      onMouseMove={(e) => {
        mx.set((e.clientX / window.innerWidth - 0.5) * 60);
        my.set((e.clientY / window.innerHeight - 0.5) * 60);
      }}
    >
      <motion.div
        style={{ scale, borderRadius: radius }}
        className="relative h-full overflow-hidden bg-gradient-to-b from-mint/60 via-cream to-peach/40"
      >
        <div className="animate-blob absolute -left-32 top-10 h-[480px] w-[480px] bg-mint opacity-70 blur-3xl" />
        <div className="animate-blob absolute -right-40 bottom-0 h-[520px] w-[520px] bg-peach opacity-60 blur-3xl [animation-delay:-6s]" />

        {ready && (
          <>
            <Float src={dog} mx={mx} my={my} depth={0.6} delay={0.5} className="bottom-[-4%] left-1/2 h-[58vh] w-[58vh] -translate-x-1/2 md:h-[68vh] md:w-[68vh]" />
            <Float src={cat} mx={mx} my={my} depth={-1.1} delay={0.8} dur={7} className="right-[4%] top-[18%] hidden h-52 w-52 md:block lg:h-64 lg:w-64" />
            <Float src={kit} mx={mx} my={my} depth={1.4} delay={1} dur={5} className="bottom-[10%] left-[4%] hidden h-48 w-48 md:block lg:h-60 lg:w-60" />
            <Float src={paw} mx={mx} my={my} depth={-1.8} delay={1.2} dur={4} className="left-[12%] top-[22%] h-16 w-16 rotate-12 md:h-24 md:w-24" />
            <Float src={paw} mx={mx} my={my} depth={2.2} delay={1.3} dur={5.5} className="bottom-[22%] right-[12%] h-12 w-12 md:h-16 md:w-16" />
          </>
        )}

        <motion.div style={{ y: textY }} className="relative z-10 flex flex-col items-center px-4 pt-32 text-center md:pt-36">
          {ready && (
            <>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, ease, delay: 0.2 }}
                className="glass mb-6 flex items-center gap-2 rounded-full px-4 py-2 text-xs font-semibold uppercase tracking-widest"
              >
                <span className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={12} className="fill-peach-deep text-peach-deep" />
                  ))}
                </span>
                5.0 on Google · Chembur, Mumbai
              </motion.div>
              <h1 className="font-display text-[13vw] font-extrabold leading-[0.85] tracking-[-0.04em] md:text-[8.5vw]">
                <SplitWords text="Good grooming." delay={0.3} />
                <br />
                <span className="font-serif font-normal italic text-mint-deep">
                  <SplitWords text="Great little moments." delay={0.55} />
                </span>
              </h1>
            </>
          )}
        </motion.div>

        {ready && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.6 }}
            className="absolute bottom-8 left-1/2 z-10 flex -translate-x-1/2 flex-col items-center gap-2 text-xs uppercase tracking-[0.3em]"
          >
            Scroll
            <motion.span
              className="h-10 w-px bg-ink"
              animate={{ scaleY: [0, 1, 0], originY: [0, 0, 1] }}
              transition={{ duration: 1.8, repeat: Infinity }}
            />
          </motion.div>
        )}
      </motion.div>
    </section>
  );
}

/* ------------------------------ marquee ------------------------------ */

function Marquee() {
  const items = ["Bath & blow-dry", "Breed haircuts", "Nail trims", "Ear cleaning", "Senior pet care", "Cat grooming", "Pet essentials", "Anxious-pet friendly"];
  const { scrollYProgress } = useScroll();
  const x = useTransform(scrollYProgress, [0, 1], ["0%", "-30%"]);
  return (
    <section className="relative -rotate-2 overflow-hidden bg-ink py-6 text-cream">
      <motion.div style={{ x }}>
        <div className="animate-marquee flex w-max gap-10 whitespace-nowrap font-display text-4xl font-bold md:text-6xl">
          {[...items, ...items].map((t, i) => (
            <span key={i} className="flex items-center gap-10">
              {t}
              <img src={paw} alt="" className="h-10 w-10" />
            </span>
          ))}
        </div>
      </motion.div>
    </section>
  );
}

/* ------------------------------ manifesto (scroll word reveal) ------------------------------ */

function Word({ w, p, range }: { w: string; p: MotionValue<number>; range: [number, number] }) {
  const o = useTransform(p, range, [0.12, 1]);
  const y = useTransform(p, range, [12, 0]);
  return (
    <motion.span style={{ opacity: o, y }} className="mr-[0.25em] inline-block">
      {w}
    </motion.span>
  );
}

function Manifesto() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 0.8", "end 0.4"] });
  const text =
    "Pet parents don't come back to us for the haircut alone. They come back because their nervous pup walked out wagging, and their senior dog was handled like family — slowly, patiently, gently.";
  const words = text.split(" ");
  const rot = useTransform(scrollYProgress, [0, 1], [-20, 20]);
  return (
    <section id="care" className="relative px-6 py-40 md:px-16">
      <motion.img style={{ rotate: rot }} src={paw} alt="" className="absolute right-8 top-16 h-24 w-24 opacity-90 md:h-36 md:w-36" />
      <div className="mx-auto max-w-6xl">
        <p className="mb-10 text-xs font-semibold uppercase tracking-[0.4em] text-mint-deep">( Our care promise )</p>
        <div ref={ref} className="font-display text-4xl font-semibold leading-[1.1] tracking-tight md:text-7xl">
          {words.map((w, i) => (
            <Word key={i} w={w} p={scrollYProgress} range={[i / words.length, (i + 1) / words.length]} />
          ))}
        </div>
      </div>
    </section>
  );
}

/* ------------------------------ horizontal services ------------------------------ */

const services = [
  { n: "01", t: "Bath & Blow-dry", d: "Gentle shampoo matched to coat and skin, warm rinse and a fluffy, tangle-free finish.", c: "clay-mint", img: kit },
  { n: "02", t: "Breed Haircuts", d: "Neat trims and full breed styles — done at your pet's pace, never rushed.", c: "clay-peach", img: dog },
  { n: "03", t: "Cat Grooming", d: "Calm, low-stress brushing, de-matting and bath care for our feline friends.", c: "clay", img: cat },
  { n: "04", t: "Paws & Hygiene", d: "Nail clipping, paw-pad tidy, ear cleaning and hygiene trims.", c: "clay-mint", img: paw },
  { n: "05", t: "Senior & Anxious Pets", d: "Extra time, extra patience. Ask us about at-home visits for senior pets.", c: "clay-peach", img: dog },
];

function Services() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref });
  const x = useTransform(scrollYProgress, [0, 1], ["0%", "-72%"]);
  const sx = useSpring(x, { stiffness: 80, damping: 25 });
  return (
    <section id="services" ref={ref} className="relative h-[400vh]">
      <div className="sticky top-0 flex h-screen items-center overflow-hidden">
        <motion.div style={{ x: sx }} className="flex gap-8 pl-6 md:pl-16">
          <div className="flex w-[80vw] shrink-0 flex-col justify-center md:w-[38vw]">
            <p className="mb-6 text-xs font-semibold uppercase tracking-[0.4em] text-mint-deep">( Services )</p>
            <h2 className="font-display text-6xl font-extrabold leading-[0.9] tracking-tight md:text-8xl">
              Everything for a <span className="font-serif font-normal italic text-peach-deep">happy</span> coat.
            </h2>
            <p className="mt-6 max-w-sm text-muted-foreground">Keep scrolling — every package is tailored to breed, coat type and temperament.</p>
          </div>
          {services.map((s, i) => (
            <motion.article
              key={s.n}
              whileHover={{ y: -16, rotate: i % 2 ? 1.5 : -1.5 }}
              transition={{ type: "spring", stiffness: 200, damping: 18 }}
              className={`${s.c} relative flex h-[70vh] w-[78vw] shrink-0 flex-col justify-between overflow-hidden rounded-[3rem] p-8 md:w-[30vw] md:p-10`}
            >
              <div className="flex items-start justify-between">
                <span className="font-serif text-6xl italic opacity-60">{s.n}</span>
                <span className="glass flex h-12 w-12 items-center justify-center rounded-full">
                  <ArrowUpRight size={18} />
                </span>
              </div>
              <motion.img
                src={s.img}
                alt=""
                loading="lazy"
                className="mx-auto h-48 w-48 object-contain md:h-56 md:w-56"
                animate={{ y: [0, -14, 0], rotate: [0, 4, 0] }}
                transition={{ duration: 5 + i, repeat: Infinity, ease: "easeInOut" }}
              />
              <div>
                <h3 className="font-display text-3xl font-bold md:text-4xl">{s.t}</h3>
                <p className="mt-3 text-sm leading-relaxed opacity-80">{s.d}</p>
              </div>
            </motion.article>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

/* ------------------------------ stats ------------------------------ */

function Stats() {
  return (
    <section className="px-6 py-32 md:px-16">
      <div className="mx-auto grid max-w-6xl gap-6 md:grid-cols-3">
        {[
          { v: <Counter to={5} decimals={1} />, l: "Google rating", c: "clay-mint" },
          { v: <Counter to={85} suffix="+" />, l: "Happy reviews", c: "clay" },
          { v: <Counter to={7} suffix=" days" />, l: "Open every week", c: "clay-peach" },
        ].map((s, i) => (
          <Reveal key={i} delay={i * 0.12}>
            <div className={`${s.c} rounded-[2.5rem] p-10`}>
              <div className="font-display text-7xl font-extrabold tracking-tight md:text-8xl">{s.v}</div>
              <div className="mt-2 text-sm font-semibold uppercase tracking-widest opacity-70">{s.l}</div>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

/* ------------------------------ first visit stacking cards ------------------------------ */

const steps = [
  { t: "Give us a call", d: "Tell us about your pet — breed, age, coat and any nerves. We'll suggest the right package and a slot.", c: "clay-mint" },
  { t: "Meet & settle in", d: "We let your pet sniff around and relax first. No rushing, no forcing — trust comes before the comb.", c: "clay-peach" },
  { t: "Pamper session", d: "Bath, trim, nails and ears done patiently, with breaks whenever your buddy needs one.", c: "clay" },
  { t: "Fluffy pick-up", d: "Collect a fresh, happy pet — and grab any shampoo, treats or accessories from our essentials shelf.", c: "clay-mint" },
];

function StepCard({ s, i, total, progress }: { s: (typeof steps)[number]; i: number; total: number; progress: MotionValue<number> }) {
  const scale = useTransform(progress, [i / total, 1], [1, 1 - (total - i) * 0.04]);
  return (
    <div className="sticky top-0 flex h-screen items-center justify-center px-6">
      <motion.div
        style={{ scale, top: `calc(10vh + ${i * 28}px)` }}
        className={`${s.c} relative flex h-[60vh] w-full max-w-5xl flex-col justify-between overflow-hidden rounded-[3rem] p-10 md:flex-row md:items-end md:p-16`}
      >
        <span className="font-serif text-[9rem] italic leading-none opacity-30 md:text-[14rem]">0{i + 1}</span>
        <div className="max-w-md">
          <h3 className="font-display text-4xl font-extrabold md:text-6xl">{s.t}</h3>
          <p className="mt-4 text-lg leading-relaxed opacity-80">{s.d}</p>
        </div>
      </motion.div>
    </div>
  );
}

function FirstVisit() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });
  return (
    <section id="visit" ref={ref} className="relative">
      <div className="px-6 pt-24 text-center md:px-16">
        <p className="mb-6 text-xs font-semibold uppercase tracking-[0.4em] text-mint-deep">( First visit )</p>
        <h2 className="font-display text-6xl font-extrabold tracking-tight md:text-8xl">
          New here? <span className="font-serif font-normal italic">Easy.</span>
        </h2>
      </div>
      {steps.map((s, i) => (
        <StepCard key={i} s={s} i={i} total={steps.length} progress={scrollYProgress} />
      ))}
    </section>
  );
}

/* ------------------------------ essentials ------------------------------ */

function Essentials() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y1 = useTransform(scrollYProgress, [0, 1], [150, -150]);
  const y2 = useTransform(scrollYProgress, [0, 1], [-100, 200]);
  const rot = useTransform(scrollYProgress, [0, 1], [-25, 25]);
  return (
    <section ref={ref} className="relative overflow-hidden bg-ink px-6 py-40 text-cream md:px-16">
      <div className="animate-blob absolute left-1/3 top-1/4 h-96 w-96 bg-mint-deep opacity-40 blur-3xl" />
      <div className="relative mx-auto grid max-w-6xl items-center gap-16 md:grid-cols-2">
        <div>
          <p className="mb-6 text-xs font-semibold uppercase tracking-[0.4em] text-mint">( Essentials shelf )</p>
          <h2 className="font-display text-5xl font-extrabold leading-[0.95] tracking-tight md:text-7xl">
            Take the <span className="font-serif font-normal italic text-peach">good stuff</span> home.
          </h2>
          <p className="mt-6 max-w-md text-lg opacity-70">
            Shampoos, brushes, collars, toys and everyday accessories — picked by groomers who actually use them. Drop by the shop or call to check what's in stock.
          </p>
          <div className="mt-10 flex flex-wrap gap-3">
            {["Shampoos", "Brushes & combs", "Collars & leashes", "Toys", "Treats"].map((t, i) => (
              <motion.span
                key={t}
                initial={{ opacity: 0, scale: 0.6 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ type: "spring", delay: i * 0.08 }}
                className="glass-dark rounded-full px-5 py-2 text-sm"
              >
                {t}
              </motion.span>
            ))}
          </div>
        </div>
        <div className="relative h-[520px]">
          <motion.div style={{ y: y1, rotate: rot }} className="glass-dark absolute left-0 top-10 h-72 w-72 rounded-[3rem] p-6">
            <img src={kit} alt="Grooming kit" loading="lazy" className="h-full w-full object-contain" />
          </motion.div>
          <motion.div style={{ y: y2 }} className="glass-dark absolute bottom-0 right-0 h-64 w-64 rounded-[3rem] p-6">
            <img src={cat} alt="Cat" loading="lazy" className="h-full w-full object-contain" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------ reviews ------------------------------ */

const reviews = [
  { q: "So patient with my dog. The haircut and bath came out perfect.", a: "Pet parent, Chembur" },
  { q: "They came home for my senior dog and were incredibly gentle with her.", a: "Pet parent, Chembur" },
  { q: "My nervous pup actually enjoys going now. That says everything.", a: "Pet parent, Mumbai" },
];

function Reviews() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((v) => (v + 1) % reviews.length), 4500);
    return () => clearInterval(t);
  }, []);
  return (
    <section id="reviews" className="px-6 py-40 md:px-16">
      <div className="mx-auto max-w-5xl text-center">
        <div className="mb-10 flex justify-center gap-1">
          {[...Array(5)].map((_, k) => (
            <motion.span key={k} initial={{ scale: 0, rotate: -90 }} whileInView={{ scale: 1, rotate: 0 }} viewport={{ once: true }} transition={{ type: "spring", delay: k * 0.1 }}>
              <Star size={32} className="fill-peach-deep text-peach-deep" />
            </motion.span>
          ))}
        </div>
        <div className="relative min-h-[260px] md:min-h-[220px]">
          <AnimatePresence mode="wait">
            <motion.blockquote
              key={i}
              initial={{ opacity: 0, y: 40, filter: "blur(12px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              exit={{ opacity: 0, y: -40, filter: "blur(12px)" }}
              transition={{ duration: 0.8, ease }}
            >
              <p className="font-serif text-4xl italic leading-tight md:text-6xl">“{reviews[i].q}”</p>
              <footer className="mt-8 text-sm font-semibold uppercase tracking-widest text-muted-foreground">{reviews[i].a}</footer>
            </motion.blockquote>
          </AnimatePresence>
        </div>
        <div className="mt-10 flex justify-center gap-2">
          {reviews.map((_, k) => (
            <button key={k} aria-label={`Review ${k + 1}`} onClick={() => setI(k)} className="h-2 overflow-hidden rounded-full bg-border" style={{ width: k === i ? 48 : 12, transition: "width .5s" }}>
              {k === i && <motion.span className="block h-full bg-ink" initial={{ width: 0 }} animate={{ width: "100%" }} transition={{ duration: 4.5, ease: "linear" }} />}
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ------------------------------ FAQ ------------------------------ */

const faqs = [
  { q: "Which pets do you groom?", a: "Dogs of all sizes and cats. Tell us the breed and coat type when you call and we'll recommend the right session." },
  { q: "Do you do home visits?", a: "We've done at-home sessions for senior pets. Call us to check availability for your area." },
  { q: "How do I book?", a: `Just call us on ${PHONE_LABEL}. We'll find a slot that suits you and your pet.` },
  { q: "My pet is anxious. Is that okay?", a: "Absolutely — that's where we shine. We go slow, take breaks and never force anything." },
];

function Faq() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section className="px-6 pb-32 md:px-16">
      <div className="mx-auto grid max-w-6xl gap-12 md:grid-cols-[1fr_1.4fr]">
        <h2 className="font-display text-5xl font-extrabold tracking-tight md:text-7xl">
          Good <span className="font-serif font-normal italic text-mint-deep">questions.</span>
        </h2>
        <div className="space-y-4">
          {faqs.map((f, i) => (
            <div key={i} className="clay overflow-hidden rounded-3xl">
              <button onClick={() => setOpen(open === i ? null : i)} className="flex w-full items-center justify-between p-6 text-left font-display text-xl font-semibold">
                {f.q}
                <motion.span animate={{ rotate: open === i ? 45 : 0 }} className="clay-mint flex h-10 w-10 shrink-0 items-center justify-center rounded-full">
                  <Plus size={18} />
                </motion.span>
              </button>
              <AnimatePresence initial={false}>
                {open === i && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.5, ease }}>
                    <p className="px-6 pb-6 text-muted-foreground">{f.a}</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ------------------------------ CTA / footer ------------------------------ */

function Footer() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end end"] });
  const y = useTransform(scrollYProgress, [0, 1], ["-40%", "0%"]);
  const scale = useTransform(scrollYProgress, [0, 1], [0.6, 1]);
  return (
    <footer ref={ref} className="relative overflow-hidden rounded-t-[4rem] bg-mint px-6 pt-28 md:px-16">
      <motion.div style={{ y }} className="mx-auto max-w-6xl">
        <div className="grid gap-12 md:grid-cols-[1.4fr_1fr]">
          <div>
            <h2 className="font-display text-5xl font-extrabold leading-[0.9] tracking-tight md:text-8xl">
              Ready for the <span className="font-serif font-normal italic">fluff-up?</span>
            </h2>
            <div className="mt-10 flex flex-wrap gap-4">
              <Magnetic>
                <a href={`tel:${PHONE}`} className="flex items-center gap-3 rounded-full bg-ink px-8 py-5 text-lg font-semibold text-cream">
                  <Phone size={18} /> {PHONE_LABEL}
                </a>
              </Magnetic>
              <Magnetic>
                <a href={MAPS} target="_blank" rel="noreferrer" className="glass flex items-center gap-3 rounded-full px-8 py-5 text-lg font-semibold">
                  <MapPin size={18} /> Get directions
                </a>
              </Magnetic>
            </div>
          </div>
          <div className="glass space-y-6 rounded-[2.5rem] p-8">
            <div className="flex gap-4">
              <MapPin className="mt-1 shrink-0" size={20} />
              <p>Shop No. 22, Pink Corner, Sindhi Society, Chembur, Mumbai 400071</p>
            </div>
            <div className="flex gap-4">
              <Clock className="mt-1 shrink-0" size={20} />
              <p>
                Open daily · 11:30 AM – 8:00 PM
                <br />
                <span className="text-sm opacity-70">Please call ahead to confirm your slot.</span>
              </p>
            </div>
            <div className="flex gap-4">
              <Heart className="mt-1 shrink-0" size={20} />
              <p>Grooming · Bathing · Pet essentials</p>
            </div>
          </div>
        </div>
      </motion.div>
      <motion.div style={{ scale }} className="mt-24 origin-bottom select-none text-center font-display text-[22vw] font-extrabold leading-[0.75] tracking-[-0.06em] text-ink/90">
        cuddle<Sparkles className="inline h-[0.3em] w-[0.3em] align-top text-peach-deep" />
      </motion.div>
      <div className="flex flex-col items-center justify-between gap-2 border-t border-ink/15 py-6 text-xs md:flex-row">
        <span>© {new Date().getFullYear()} Cuddle Grooms, Chembur</span>
        <span>Good grooming. Great little moments.</span>
      </div>
    </footer>
  );
}

function ScrollBar() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 120, damping: 30 });
  return <motion.div style={{ scaleX }} className="fixed inset-x-0 top-0 z-[60] h-1 origin-left bg-peach-deep" />;
}

function Home() {
  useLenis();
  const [ready, setReady] = useState(false);
  return (
    <main className="grain relative">
      <AnimatePresence>{!ready && <Preloader onDone={() => setReady(true)} />}</AnimatePresence>
      <Cursor />
      <ScrollBar />
      <Nav />
      <Hero ready={ready} />
      <Marquee />
      <Manifesto />
      <Services />
      <Stats />
      <FirstVisit />
      <Essentials />
      <Reviews />
      <Faq />
      <Footer />
    </main>
  );
}
