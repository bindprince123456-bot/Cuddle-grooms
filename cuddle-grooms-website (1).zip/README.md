# Cuddle Grooms — Pet Grooming Website

This is the full source code of the website (TanStack Start + React + Tailwind CSS v4 + framer-motion).

## How to run locally

1. Install [Node.js](https://nodejs.org) (v20 or newer) and [Bun](https://bun.sh) (or use npm instead).
2. Open a terminal in this folder.
3. Install dependencies:
   - With Bun: `bun install`
   - With npm: `npm install`
4. Start the dev server:
   - With Bun: `bun run dev`
   - With npm: `npm run dev`
5. Open the URL shown in the terminal (usually http://localhost:8080).

## Building for production

- With Bun: `bun run build`
- With npm: `npm run build`

The build output goes to `dist/` and can be deployed to any Node.js/Edge host.

## Where things live

- `src/routes/index.tsx` — the whole landing page (hero, services, products, contact, etc.)
- `src/styles.css` — global styles, animations, design tokens
- `src/assets/` — images used on the page

## Notes

- Reviews, timings and some service details on the page are placeholders — replace them with the real business details before going live.
